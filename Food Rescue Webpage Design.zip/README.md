
  # Food Rescue Webpage Design

  This is a code bundle for Food Rescue Webpage Design. The original project is available at https://www.figma.com/design/I4iy2CdVyfwTJmcHyRA3fA/Food-Rescue-Webpage-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  